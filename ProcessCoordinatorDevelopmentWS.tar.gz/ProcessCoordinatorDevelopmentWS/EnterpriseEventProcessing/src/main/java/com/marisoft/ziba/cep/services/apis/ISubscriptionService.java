package com.marisoft.ziba.cep.services.apis;

/**
 * 
 * @author shaf3y
 * To enable dynamic registration of producers and consumers
 * ,such allowing event handlers to find appropriate channels
 * to subscribe and to receive events from those channels
 */
public interface ISubscriptionService {

}
