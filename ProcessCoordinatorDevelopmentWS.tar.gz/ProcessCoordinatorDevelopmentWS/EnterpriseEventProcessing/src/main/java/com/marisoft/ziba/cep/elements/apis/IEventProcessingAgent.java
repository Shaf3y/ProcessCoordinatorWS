package com.marisoft.ziba.cep.elements.apis;

public interface IEventProcessingAgent extends IEPNElement {

}
