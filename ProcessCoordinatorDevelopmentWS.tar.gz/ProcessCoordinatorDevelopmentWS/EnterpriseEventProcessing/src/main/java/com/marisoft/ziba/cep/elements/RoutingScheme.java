package com.marisoft.ziba.cep.elements;

public enum RoutingScheme {
	FIXED,
	TYPE_BASED,
	CONTENT_BASED;
}
