package com.marisoft.ziba.cep.elements;

import com.marisoft.ziba.cep.elements.apis.IEventType;


public class EventType implements IEventType {

	/** [R] Uniquely identifies the type */
	private String identifier;
	
	private String description;
	
	private ElementType type;

	/** [R] Denotes whether the event type is a composition of other events or not */
	private boolean composed;

	/** [R] Denotes the atom of time from a particular application's point of view */
	private TemporalGranularity granularity;

	/** [R] Event Type's Header */
	private EventHeader header;

	/** [R] Event Type's Body */
	private EventBody body;
	
	public EventType() {
		header = new EventHeader();
		body = new EventBody();
	}
	
	public String getIdentifier() {		
		return this.identifier;
	}
	
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	
	public String getDescription() {
		return this.description;
	}
	
	public ElementType getType() {
		return this.type;
	}
	
	public void setType(ElementType type) {
		this.type = type;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public boolean isComposed() {
		return composed;
	}

	public void setComposed(boolean composed) {
		this.composed = composed;
	}

	public TemporalGranularity getGranularity() {
		return granularity;
	}

	public void setGranularity(TemporalGranularity granularity) {
		this.granularity = granularity;
	}

	public EventHeader getHeader() {
		return header;
	}

	public EventBody getBody() {
		return body;
	}
}
