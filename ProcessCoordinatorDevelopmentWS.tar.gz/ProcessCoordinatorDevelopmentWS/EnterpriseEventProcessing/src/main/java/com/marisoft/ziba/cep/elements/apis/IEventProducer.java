package com.marisoft.ziba.cep.elements.apis;

import java.util.List;

public interface IEventProducer extends IEPNElement {

	boolean isQueriable();
	List<IEventChannel> getOutChannels();
}
