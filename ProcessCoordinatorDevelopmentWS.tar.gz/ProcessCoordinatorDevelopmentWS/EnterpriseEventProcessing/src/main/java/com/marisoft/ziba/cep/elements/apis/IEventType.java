package com.marisoft.ziba.cep.elements.apis;

import com.marisoft.ziba.cep.elements.EventBody;
import com.marisoft.ziba.cep.elements.EventHeader;
import com.marisoft.ziba.cep.elements.TemporalGranularity;

public interface IEventType extends IEPNElement {

	boolean isComposed();
	TemporalGranularity getGranularity();
	EventHeader getHeader();
	EventBody getBody();
}
