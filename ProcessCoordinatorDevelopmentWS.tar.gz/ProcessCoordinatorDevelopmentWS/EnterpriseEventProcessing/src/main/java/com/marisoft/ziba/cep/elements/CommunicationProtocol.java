package com.marisoft.ziba.cep.elements;

public enum CommunicationProtocol {
	TCP,
	UDP,
	HTTP,
	VM;
}
