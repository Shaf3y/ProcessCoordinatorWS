package com.marisoft.ziba.cep.elements.apis;

import java.util.List;

import com.marisoft.ziba.cep.elements.RoutingScheme;

public interface IEventChannel extends IEPNElement {

	RoutingScheme getRoutingScheme();
	List<IEventType> getEventTypes();
}
