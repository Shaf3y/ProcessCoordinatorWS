package com.marisoft.ziba.cep;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import com.espertech.esper.client.EventBean;
import com.espertech.esper.client.UpdateListener;

@Component
public class BProcessEventListener implements UpdateListener {
	
//	@Autowired
//	private JmsTemplate jmsTemplate;
	
	public void update(EventBean[] newEvents, EventBean[] oldEvents) {
		// TODO Auto-generated method stub
		
	}

}
