package com.marisoft.ziba.cep.elements;

public enum MessagingMode {
	P2P,
	PUB_SUB;
}
