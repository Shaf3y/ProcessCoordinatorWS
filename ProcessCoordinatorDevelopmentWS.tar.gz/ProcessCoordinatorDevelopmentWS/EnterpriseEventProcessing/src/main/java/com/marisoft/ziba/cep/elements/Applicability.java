package com.marisoft.ziba.cep.elements;

public enum Applicability {

	REQUIRED,
	OPTIONAL,
	NOT_APPLICABLE;

}
