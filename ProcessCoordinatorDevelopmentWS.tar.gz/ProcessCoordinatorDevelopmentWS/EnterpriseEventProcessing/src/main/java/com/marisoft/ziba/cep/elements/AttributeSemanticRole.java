package com.marisoft.ziba.cep.elements;

public enum AttributeSemanticRole {
	CommonAttribute,
	EntityReference;
}
