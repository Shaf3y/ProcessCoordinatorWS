package com.marisoft.ziba.cep.elements;

public enum ElementType {
	
	ABSTRACT_TYPE,
	CLASS,
	SINGLE_INSTANCE;
}
