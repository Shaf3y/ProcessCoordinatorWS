package com.marisoft.ziba.cep.elements;

public enum EventRelationshipType {

	MEMBER,
	MEMBERSHIP,
	GENERALIZATION,
	SPECIALIZATION,
	RETRACTION;
}
