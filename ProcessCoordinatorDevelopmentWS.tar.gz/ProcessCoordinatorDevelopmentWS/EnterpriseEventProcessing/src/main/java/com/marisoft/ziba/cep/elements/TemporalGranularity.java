package com.marisoft.ziba.cep.elements;

public enum TemporalGranularity {

	milliscondes,
	seconds,
	minutes,
	hours,
	days,
	months,
	years,
	quarters,
	periodical
}
